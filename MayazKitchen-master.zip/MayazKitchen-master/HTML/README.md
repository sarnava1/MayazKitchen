# MayazKitchen
This was a project I was building when I was learning web d nicely with dedication for the first time. It only has bootstrap, css and html. It is very poorly organized but pardon me for that. I will try to make the project concept clear as much as I can through the README.md file.

1. safecopy3.html is the starting index file. Treat it as the index file of the project. 
2. I was learning web d when I was creating the project so no formal rules have been followed here. I am extremely sorry for this.
3. All the images used are in the main folder only. There are no separate image folder.
4. All the css files used are in the main folder only. There are no separate public folder.
5. All the files are made using basic html and bootstrap and very less js is used.
6. I have used the W3 schools for my learning of bootstrap and a lot of examples from there are used.
7. Few files are also directly taken from open source projects with modifications of my own.
8. There will be a hell lot of iisues in this project.
9. First timers and noobies can try solving the issues over here. It will lead to their betterment.
10. Interested developers can club the images together and the css files together and make modifications for that in the html files.
11. https://sarnava1.github.io/MayazKitchen/ is the link of the page wheere this site is hosted. 
